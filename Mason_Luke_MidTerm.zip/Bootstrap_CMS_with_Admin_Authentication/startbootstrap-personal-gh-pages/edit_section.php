<?php
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: resume.php');
    exit;
}

$section = $_GET['section'] ?? '';
$newContent = $_POST['description'] ?? '';

if ($section && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $file = 'Mason_Luke.php';
    
    // Include the file and load existing data
    include $file;

    // Update content based on the section being edited
    if ($section === 'experience') {
        $experience['description'] = $newContent;
    } elseif ($section === 'education') {
        $education['description'] = $newContent;
    } elseif ($section === 'skills') {
        $skills = array_map('trim', explode(',', $newContent)); // Convert comma-separated input to an array
    }

    // Prepare the content for rewriting
    $content = "<?php\n";
    $content .= "\$experience = " . var_export($experience, true) . ";\n\n";
    $content .= "\$education = " . var_export($education, true) . ";\n\n";
    $content .= "\$skills = " . var_export($skills, true) . ";\n\n";
    $content .= "\$email = '" . addslashes($email) . "';\n";
    $content .= "\$phone = '" . addslashes($phone) . "';\n";
    $content .= "\$linkedin_url = '" . addslashes($linkedin_url) . "';\n";
    $content .= "\$github_url = '" . addslashes($github_url) . "';\n";
    $content .= "?>";

    // Save the modified content back to Mason_Luke.php
    file_put_contents($file, $content);

    header('Location: resume.php?edit=true');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit <?php echo htmlspecialchars($section); ?></title>
    <link href="css/styles.css" rel="stylesheet">
</head>
<body>
    <h1>Edit <?php echo htmlspecialchars($section); ?></h1>
    <form method="post">
        <textarea name="description" rows="5" cols="50" placeholder="Enter new content here"></textarea><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>