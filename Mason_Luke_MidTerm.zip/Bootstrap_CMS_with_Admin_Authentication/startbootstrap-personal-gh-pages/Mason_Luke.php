<?php
$experience = array (
  'title' => 'Staff Member',
  'company' => 'Planet Fitness',
  'duration' => '2023 - Present',
  'description' => 'hi',
);

$education = array (
  'degree' => 'Bachelor\'s in Cybersecurity',
  'institution' => 'Northern Kentucky University',
  'years' => '2021 - Expected 2025',
  'description' => 'my',
);

$skills = array (
  0 => 'name',
);

$email = 'Lukem1@mymail.nku.edu';
$phone = '513-507-5315';
$linkedin_url = 'https://www.linkedin.com/in/mason-luke-2506302b7/';
$github_url = 'https://github.com/Lukem25';
?>