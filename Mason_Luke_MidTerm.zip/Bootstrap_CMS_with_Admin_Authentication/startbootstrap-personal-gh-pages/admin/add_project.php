
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

if (isset($_POST['save'])) {
    $filename = $_POST['filename'];
    $content = $_POST['content'];
    file_put_contents("../projects/$filename.txt", $content);
    echo "Project added!";
}
?>
<form method="post">
    <input type="text" name="filename" placeholder="Project Name">
    <textarea name="content" placeholder="Project Description"></textarea>
    <button type="submit" name="save">Save</button>
</form>
