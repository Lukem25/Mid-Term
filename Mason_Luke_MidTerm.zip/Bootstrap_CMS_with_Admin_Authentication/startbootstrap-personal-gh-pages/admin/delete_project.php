
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$file = $_GET['file'];
$filepath = "../projects/$file.txt";
if (file_exists($filepath)) {
    unlink($filepath);
    echo "Project deleted!";
}
header('Location: list_projects.php');
?>
