
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$files = glob('../projects/*.txt');
echo "<h1>Manage Projects</h1>";
echo "<a href='add_project.php'>Add New Project</a><br><br>";

foreach ($files as $file) {
    $content = file_get_contents($file);
    $filename = basename($file, ".txt");
    echo "<div><h2>$filename</h2><p>$content</p>";
    echo "<a href='edit_project.php?file=$filename'>Edit</a> | <a href='delete_project.php?file=$filename'>Delete</a></div><hr>";
}
?>
