
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$files = glob('../posts/*.txt');
echo "<h1>Manage Posts</h1>";
echo "<a href='add_post.php'>Add New Post</a><br><br>";

foreach ($files as $file) {
    $content = file_get_contents($file);
    $filename = basename($file, ".txt");
    echo "<div><h2>$filename</h2><p>$content</p>";
    echo "<a href='edit_post.php?file=$filename'>Edit</a> | <a href='delete_post.php?file=$filename'>Delete</a></div><hr>";
}
?>
