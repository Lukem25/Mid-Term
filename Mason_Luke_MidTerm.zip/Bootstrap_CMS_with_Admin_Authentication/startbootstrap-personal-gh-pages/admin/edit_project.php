
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$file = $_GET['file'];
$filepath = "../projects/$file.txt";

if (isset($_POST['content'])) {
    file_put_contents($filepath, $_POST['content']);
    echo "Project updated!";
}

$content = file_get_contents($filepath);
?>
<form method="post">
    <textarea name="content"><?php echo htmlspecialchars($content); ?></textarea>
    <button type="submit">Save</button>
</form>
