
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

if (isset($_POST['save'])) {
    $filename = $_POST['filename'];
    $content = $_POST['content'];
    file_put_contents("../posts/$filename.txt", $content);
    echo "Post added!";
}
?>
<form method="post">
    <input type="text" name="filename" placeholder="Post Title">
    <textarea name="content" placeholder="Post Content"></textarea>
    <button type="submit" name="save">Save</button>
</form>
