<?php
session_start();

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate credentials
    if ($username == 'admin' && $password == 'password') {
        $_SESSION['admin'] = true;
        header('Location: dashboard.php'); // Ensure dashboard.php is in the same directory
        exit();
    } else {
        echo "Invalid credentials!";
    }
}
?>