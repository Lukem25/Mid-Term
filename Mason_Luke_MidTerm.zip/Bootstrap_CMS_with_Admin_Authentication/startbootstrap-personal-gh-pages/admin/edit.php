<?php
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: http://localhost/Bootstrap_CMS_with_Admin_Authentication/startbootstrap-personal-gh-pages/index.php');
    exit;
}

$section = $_GET['section'] ?? '';
$filename = '../content/about.txt';

// Handle form submission to save the updated content
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = $_POST['content'] ?? '';
    file_put_contents($filename, $content);
    echo "Content saved successfully. Redirecting to the main page...";
    header('Location: http://localhost/Bootstrap_CMS_with_Admin_Authentication/startbootstrap-personal-gh-pages/index.php');
    exit;
}

// Load current content for the section
$currentContent = file_exists($filename) ? file_get_contents($filename) : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Content</title>
    <link href="../css/styles.css" rel="stylesheet">
</head>
<body>
    <h1>Edit Content - About Me</h1>
    <form method="post">
        <textarea name="content" rows="10" cols="50"><?php echo htmlspecialchars($currentContent); ?></textarea><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>