<?php
session_start();
include('Mason_Luke.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resume</title>
    <link href="css/styles.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
        <div class="container px-5">
            <a class="navbar-brand" href="index.php"><span class="fw-bolder text-primary">Mason Luke</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 small fw-bolder">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="resume.php">Resume</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container my-5">
        <h1 class="text-primary">Resume</h1>
        <a href="Lukem_resume.docx" class="btn btn-primary mb-3" download>Download Resume</a>

        <!-- Experience Section -->
        <section>
            <h2>Experience</h2>
            <div class="card mb-3">
                <div class="card-body">
                    <p><strong><?php echo htmlspecialchars($experience['title'] ?? ''); ?></strong> - <?php echo htmlspecialchars($experience['company'] ?? ''); ?></p>
                    <p><?php echo htmlspecialchars($experience['duration'] ?? ''); ?></p>
                    <p><?php echo htmlspecialchars($experience['description'] ?? ''); ?></p>
                    <?php if (isset($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
                        <a href="edit_section.php?section=experience" class="btn btn-danger">Edit Experience</a>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Education Section -->
        <section>
            <h2>Education</h2>
            <div class="card mb-3">
                <div class="card-body">
                    <p><strong><?php echo htmlspecialchars($education['degree'] ?? ''); ?></strong></p>
                    <p><?php echo htmlspecialchars($education['institution'] ?? ''); ?> - <?php echo htmlspecialchars($education['years'] ?? ''); ?></p>
                    <p><?php echo htmlspecialchars($education['description'] ?? ''); ?></p>
                    <?php if (isset($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
                        <a href="edit_section.php?section=education" class="btn btn-danger">Edit Education</a>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <!-- Skills Section -->
        <section>
            <h2>Skills</h2>
            <ul>
                <?php foreach ($skills as $skill): ?>
                    <li><?php echo htmlspecialchars($skill); ?></li>
                <?php endforeach; ?>
            </ul>
            <?php if (isset($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
                <a href="edit_section.php?section=skills" class="btn btn-danger">Edit Skills</a>
            <?php endif; ?>
        </section>

        <!-- Contact Section -->
        <section>
            <h2>Contact Information</h2>
            <p>Email: <?php echo htmlspecialchars($email); ?></p>
            <p>Phone: <?php echo htmlspecialchars($phone); ?></p>
            <p>LinkedIn: <a href="<?php echo htmlspecialchars($linkedin_url); ?>" target="_blank"><?php echo htmlspecialchars($linkedin_url); ?></a></p>
            <p>GitHub: <a href="<?php echo htmlspecialchars($github_url); ?>" target="_blank"><?php echo htmlspecialchars($github_url); ?></a></p>
        </section>
    </div>

    <!-- Bootstrap JavaScript and jQuery -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>